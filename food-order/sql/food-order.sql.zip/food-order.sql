-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 07, 2022 at 05:06 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food-order`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `full_name`, `username`, `password`) VALUES
(37, 'admin', 'admin', 'admin'),
(39, 'tarun', 'tarun', 'tarun'),
(44, 'ashwini', 'ashwini', 'ashwini');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `title`, `image_name`, `featured`, `active`) VALUES
(17, 'Pizza', 'food_category_741.jpg', 'Yes', 'Yes'),
(19, 'Burger', 'food_category_669.jpg', 'Yes', 'Yes'),
(20, 'Momo', 'food_category_876.jpg', 'Yes', 'Yes'),
(21, 'Soup', 'food_category_112.webp', 'No', 'No'),
(22, 'Desserts', 'food_category_403.jpg', 'No', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_food`
--

CREATE TABLE `tbl_food` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_food`
--

INSERT INTO `tbl_food` (`id`, `title`, `description`, `price`, `image_name`, `category_id`, `featured`, `active`) VALUES
(12, 'up2', 'up', '362.00', 'food_name_3426.jpg', 19, 'No', 'Yes'),
(13, 'Non et placeat opti', 'Nulla dolor est dist', '196.00', 'food_name_6197.jpg', 20, 'Yes', 'Yes'),
(14, 'Et velit ea alias fu', 'Veniam magna esse t', '109.00', 'food_name_1197.jpg', 20, 'Yes', 'Yes'),
(15, 'Exercitation repudia', 'Qui at qui quaerat o', '44.00', 'food_name_7427.jpg', 20, 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(10) UNSIGNED NOT NULL,
  `food` varchar(150) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` varchar(50) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `customer_contact` varchar(20) NOT NULL,
  `customer_email` varchar(50) NOT NULL,
  `customer_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `food`, `price`, `qty`, `total`, `order_date`, `status`, `customer_name`, `customer_contact`, `customer_email`, `customer_address`) VALUES
(1, 'Non et placeat opti', '196.00', 2, '392.00', '2022-08-31 10:05:22', 'Cancelled', 'Octavia Rush', '+1 (518) 951-3217', 'tajanepe@mailinator.com', 'Odio veritatis volup'),
(2, 'Non et placeat opti', '196.00', 3, '588.00', '2022-08-31 10:09:55', 'Ordered', 'Gemma Burks', '+1 (293) 295-2926', 'dujydex@mailinator.com', 'Sed quia dolor repud'),
(3, 'Non et placeat opti', '196.00', 5, '980.00', '2022-08-31 10:11:59', 'Ordered', 'Jackson Kelley', '+1 (644) 197-7964', 'fokifunaku@mailinator.com', 'In minima aut magni '),
(4, 'Exercitation repudia', '44.00', 1, '44.00', '2022-08-31 10:14:05', 'Ordered', 'Damon Clayton', '+1 (534) 374-3002', 'lyse@mailinator.com', 'Nobis consectetur i'),
(5, 'Non et placeat opti', '196.00', 4, '784.00', '2022-08-31 10:15:16', 'Delivered', 'Juliet Dotson', '+1 (614) 391-2159', 'kajif@mailinator.com', 'Id deserunt irure ni'),
(6, 'Non et placeat opti', '196.00', 2, '392.00', '2022-08-31 10:17:51', 'Delivered', 'uyu', 'ryury', 'hokyco@mailinator.com', 'up2'),
(7, 'Non et placeat opti', '196.00', 2, '392.00', '2022-08-31 10:18:07', 'On Delivary', 'up', 'up', 'up', 'update');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_food`
--
ALTER TABLE `tbl_food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_food`
--
ALTER TABLE `tbl_food`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
